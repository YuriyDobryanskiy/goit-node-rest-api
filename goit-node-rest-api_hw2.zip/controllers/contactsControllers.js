import contactsService from "../services/contactsServices.js";

export const getAllContacts = (req, res) => {};

export const getOneContact = (req, res) => {};

export const deleteContact = (req, res) => {};

export const createContact = (req, res) => {};

export const updateContact = (req, res) => {};
