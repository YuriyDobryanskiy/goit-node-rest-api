import Joi from "joi";

export const createContactSchema = Joi.object({

})

export const updateContactSchema = Joi.object({

})